# Commandes utiles
**Pour le bon fonctionnement de l'application il est obligatoire de réaliser ces commandes :**
* Pour installer les dépendances :
  * ```npm install```  ou ```npm i```
* Pour lancer l'application :
  * ```npx expo start``` ou ```npm start```
 
# Comment utiliser l'application
**Il faut obligatoirement que l'appareil que vous utilisé pour tester l'application soit sur le même réseau que l'appareil sur lequelle vous avez lancé l'application**
* Sur smartphone :
  * Tout d'abord télécharger l'application Expo GO
  * Ensuite il suffit de scanner le qrCode avec votre téléphone lors du lancement de l'application sur VSCode
 
* Sur pc :
  * Installer Android Studio si ce n'est pas déjà le cas
  * Lancer le smartphone sur Android Studio
  * Une fois le lancement de l'application sur VSCode effectué, il suffit de taper la touche **a** dans le terminal, ce qui ouvrira l'application sur Android Studio

# Comptes utilisateurs : 
 * Email : pereirabaptiste1@gmail.com
 * Mot de passe : test
